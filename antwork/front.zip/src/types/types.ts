export interface UserData{
    user_id: string;
    user_password: string;
    user_pwCheck: string;
    user_email: string;
}