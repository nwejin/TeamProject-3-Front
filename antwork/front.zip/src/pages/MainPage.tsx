const MainPage=()=>{
    return<>
        <div style={{height:'1000px'}}>hi</div>
        
    </>
}
export default MainPage;